import React from 'react';

function PageTitle()
{
   return(
     <h1 id="title">COP 4331 MERN Stack Demo</h1>
   );
};

export default PageTitle;